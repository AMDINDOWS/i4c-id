<?php
       
       
           echo "    " . date("Y-m-d") . "<tr> &nbsp";
           echo "    "  .  date("l"). "<tr> &nbsp";
           date_default_timezone_set("Asia/Calcutta");
           echo "    " . date("h:i:sa");
    
     ?>